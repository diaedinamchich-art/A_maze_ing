from .maze import MazeGenerator
